function scrollToSection(contact) {
    const section = document.getElementById(contact);
    section.scrollIntoView({ behavior: "smooth" });
}